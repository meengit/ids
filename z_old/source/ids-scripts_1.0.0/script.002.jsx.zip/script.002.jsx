﻿// script.002.jsx

var newDoc = app.documents.add();
newDoc;