﻿// script.001.jsx

app.documents.add();