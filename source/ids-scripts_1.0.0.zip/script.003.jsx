﻿// script.003.jsx

var newDoc = app.documents.add();
app.activeDocument.save(new File('~/Desktop/myname.indd'));